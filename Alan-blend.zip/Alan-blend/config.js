require("dotenv").config();
module.exports = {
  botToken: process.env.BOT_TOKEN,
  hostURL: process.env.HOST_URL,
};
